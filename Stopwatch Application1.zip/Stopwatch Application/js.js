let timerInterval = null;
let running = false;
let h = 0, m = 0, s = 0;

const timeDisplay = document.getElementById("display");
const startButton = document.getElementById("start");
const pauseButton = document.getElementById("pause");
const resetButton = document.getElementById("reset");
const lapButton = document.getElementById("lap");
const lapsList = document.getElementById("laps");

// Updates the stopwatch display
function showTime() {
  s++;
  if (s === 60) {
    s = 0;
    m++;
  }
  if (m === 60) {
    m = 0;
    h++;
  }
 
  timeDisplay.textContent =
    (h < 10 ? "0" + h : h) + ":" +
    (m < 10 ? "0" + m : m) + ":" +
    (s < 10 ? "0" + s : s);
}

// Start the stopwatch
startButton.addEventListener("click", () => {
  if (!running) {
    timerInterval = setInterval(showTime, 1000);
    running = true;
    startButton.classList.add("running"); // Add blue color
  }
});

// Pause the stopwatch
pauseButton.addEventListener("click", () => {
  clearInterval(timerInterval);
  running = false;
   startButton.classList.remove("running"); // Remove blue color
});

// Reset everything
resetButton.addEventListener("click", () => {
  clearInterval(timerInterval);
  running = false;
  h = m = s = 0;
  timeDisplay.textContent = "00:00:00";
  lapsList.innerHTML = "";
  startButton.classList.remove("running"); // Remove blue color
});

// Record a lap
lapButton.addEventListener("click", () => {
  const lapItem = document.createElement("li");
  lapItem.textContent = timeDisplay.textContent;
  lapsList.appendChild(lapItem);
});