let board = ["", "", "", "", "", "", "", "", ""];
let currentPlayer = "X";
let gameOver = false;

const cells = document.querySelectorAll(".cell");
const message = document.getElementById("message");
const resetBtn = document.getElementById("reset");

// winning combinations
const winPatterns = [
  [0,1,2], [3,4,5], [6,7,8], // rows
  [0,3,6], [1,4,7], [2,5,8], // cols
  [0,4,8], [2,4,6]           // diagonals
];

function checkWinner() {
  for (let pattern of winPatterns) {
    let [a,b,c] = pattern;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { player: board[a], pattern }; // return winner + winning cells
    }
  }
  return null;
}

function handleClick(e) {
  let idx = e.target.dataset.id;

  if (board[idx] !== "" || gameOver) return;

  board[idx] = currentPlayer;
  e.target.textContent = currentPlayer;
  e.target.classList.add(currentPlayer.toLowerCase()); // add X/O style

  let result = checkWinner();
  if (result) {
    let { player, pattern } = result;
    message.textContent = `Player ${player} wins! 🎉`;
    pattern.forEach(i => cells[i].classList.add("winner")); // highlight
    gameOver = true;
    return;
  }

  if (!board.includes("")) {
    message.textContent = "It's a draw!";
    gameOver = true;
    return;
  }

  currentPlayer = currentPlayer === "X" ? "O" : "X";
  message.textContent = `Player ${currentPlayer}'s turn`;
}

function resetGame() {
  board = ["", "", "", "", "", "", "", "", ""];
  gameOver = false;
  currentPlayer = "X";
  message.textContent = "Player X's turn";
  cells.forEach(c => {
    c.textContent = "";
    c.classList.remove("x", "o", "winner"); // clear styles too
  });
}

cells.forEach(cell => cell.addEventListener("click", handleClick));
resetBtn.addEventListener("click", resetGame);
